import cv2
import easyocr
import sqlite3
import tkinter as tk
from tkinter import messagebox
import threading
import subprocess
import atexit

# Path to the Haar Cascade classifier XML file for license plate detection
harcascade = "C:/Users/pavel/Car-Number-plate-detection/model/haarcascade_russian_plate_number.xml"

# Function to find the first available camera
def find_available_camera():
    for i in range(10):
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            print(f"Camera {i} is available.")
            return cap
        cap.release()
    print("No available cameras found.")
    return None

# Accessing the first available camera
cap = find_available_camera()

if cap is None:
    print("No cameras found. Exiting.")
    exit()

# Setting the dimensions for the video stream
cap.set(3, 1280) # width
cap.set(4, 720) # height

# Minimum area for a detected region to be considered a license plate
min_area = 70
count = 0

# Initialize the EasyOCR reader
reader = easyocr.Reader(['en'])

# Function to create the database and table for license plates
def create_license_plates_database():
    conn = sqlite3.connect('license_plates.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS license_plates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            plate_number TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()
    print("License plates database and table created successfully.")

# Function to create the database and table for used plates
def create_used_plates_database():
    conn = sqlite3.connect('used_plates.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS used_plates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            plate_number TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()
    print("Used plates database and table created successfully.")

# Function to add a license plate to the database
def add_license_plate(plate_number):
    conn = sqlite3.connect('license_plates.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO license_plates (plate_number) VALUES (?)', (plate_number,))
    conn.commit()
    conn.close()
    print(f"License plate {plate_number} added to the database.")

# Function to add a used plate to the database
def add_used_plate(plate_number):
    conn = sqlite3.connect('used_plates.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO used_plates (plate_number) VALUES (?)', (plate_number,))
    conn.commit()
    conn.close()
    print(f"License plate {plate_number} marked as used.")

# Function to check if a license plate exists in the database
def license_plate_exists(plate_number):
    conn = sqlite3.connect('license_plates.db')
    cursor = conn.cursor()
    cursor.execute('SELECT 1 FROM license_plates WHERE plate_number LIKE ?', (plate_number[:5] + '%',))
    exists = cursor.fetchone() is not None
    conn.close()
    return exists

# Function to check if a license plate is used
def license_plate_used(plate_number):
    conn = sqlite3.connect('used_plates.db')
    cursor = conn.cursor()
    cursor.execute('SELECT 1 FROM used_plates WHERE plate_number LIKE ?', (plate_number[:5] + '%',))
    used = cursor.fetchone() is not None
    conn.close()
    return used

# Function to open the command prompt
def open_command_prompt():
    subprocess.Popen('cmd.exe')

# Function to create the GUI
def create_gui():
    def submit_plate():
        plate_number = entry.get().upper()
        if license_plate_exists(plate_number):
            messagebox.showinfo("Info", f"License plate {plate_number} already exists in the database!")
            open_command_prompt()  # Open command prompt if the plate already exists
        elif license_plate_used(plate_number):
            messagebox.showinfo("Info", f"License plate {plate_number} has already been used!")
        else:
            add_license_plate(plate_number)
            add_used_plate(plate_number)
            messagebox.showinfo("Success", f"License plate {plate_number} added successfully!")

    root = tk.Tk()
    root.title("Add License Plate")

    label = tk.Label(root, text="Enter License Plate Number:")
    label.pack(pady=10)

    entry = tk.Entry(root)
    entry.pack(pady=10)

    submit_button = tk.Button(root, text="Submit", command=submit_plate)
    submit_button.pack(pady=10)

    root.mainloop()

# Function to reset the used plates database
def reset_used_plates_database():
    conn = sqlite3.connect('used_plates.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM used_plates')
    conn.commit()
    conn.close()
    print("Used plates database reset successfully.")

# Register the reset function to be called at exit
atexit.register(reset_used_plates_database)

# Create the databases and tables
create_license_plates_database()
create_used_plates_database()

# Start the GUI in a separate thread
gui_thread = threading.Thread(target=create_gui)
gui_thread.start()

while True:
    # Reading frames from the webcam
    success, img = cap.read()

    if not success:
        print("Failed to capture image from the camera.")
        break

    # Creating a license plate classifier
    plate_cascade = cv2.CascadeClassifier(harcascade)

    # Converting the frame to grayscale for easier processing
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Detecting license plates in the grayscale image
    plates = plate_cascade.detectMultiScale(img_gray, 1.1, 4)

    # Iterating through the detected plates
    for (x, y, w, h) in plates:
        area = w * h

        # Checking if the detected area is larger than the minimum area
        if area > min_area:
            # Drawing a rectangle around the detected license plate
            cv2.rectangle(img, (x, y), (x+w, y+h), (0, 255, 0), 2)

            # Adding a label for the detected plate
            cv2.putText(img, "Hello Number", (x, y-5), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, (255, 0, 255), 2)

            # Extracting the region of interest (ROI) for the license plate
            img_roi = img[y: y+h, x:x+w]

            # Displaying the ROI in a separate window
            cv2.imshow("ROI", img_roi)

            # Perform OCR on the ROI
            results = reader.readtext(img_roi)
            for (bbox, text, prob) in results:
                print(f"Detected text: {text} with probability: {prob}")
                if license_plate_exists(text):
                    print(f"License plate {text} already exists in the database.")
                    open_command_prompt()  # Open command prompt if the plate already exists

    # Displaying the result with detected plates
    cv2.imshow("Result", img)

    # Saving the plate when 's' key is pressed
    if cv2.waitKey(1) & 0xFF == ord('s'):
        # Writing the plate image to a file with a count in the filename
        cv2.imwrite("plates/scaned_img_" + str(count) + ".jpg", img_roi)

        # Displaying a message that the plate is saved
        cv2.rectangle(img, (0, 200), (640, 300), (0, 255, 0), cv2.FILLED)
        cv2.putText(img, "Plate Saved", (150, 265), cv2.FONT_HERSHEY_COMPLEX_SMALL, 2, (0, 0, 255), 2)
        cv2.imshow("Results", img)

        # Waiting for 500 milliseconds before continuing
        cv2.waitKey(500)

        # Incrementing the count for the next saved plate
        count += 1

    # Break the loop if 'q' key is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam and close all OpenCV windows
cap.release()
cv2.destroyAllWindows()

import cv2
import easyocr
import sqlite3
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import subprocess
import atexit
import os
import time
from datetime import date

# Путь к папке для сохранения изображений
SAVE_FOLDER = "plates"
if not os.path.exists(SAVE_FOLDER):
    os.makedirs(SAVE_FOLDER)

# Path to the Haar Cascade classifier XML file for license plate detection
harcascade = "/Users/pavellabusev/Downloads/Car-Number-plate-detection/model/haarcascade_russian_plate_number.xml"

# Function to find the first available camera
def find_available_camera():
    for i in range(10):
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            print(f"Camera {i} is available.")
            return cap
        cap.release()
    print("No available cameras found.")
    return None

# Accessing the first available camera
cap = find_available_camera()

if cap is None:
    print("No cameras found. Exiting.")
    exit()

# Setting the dimensions for the video stream
cap.set(3, 640)  # width - Adjusted for Tkinter window
cap.set(4, 480)  # height - Adjusted for Tkinter window

# Minimum area for a detected region to be considered a license plate
min_area = 70
count = 0

# Initialize the EasyOCR reader
reader = easyocr.Reader(['en'])

# Database file names
LICENSE_PLATES_DB_FILE = 'license_plates.db'
USED_PLATES_DB_FILE = 'used_plates.db'

# Function to check if a database file exists
def database_exists(db_file):
    return os.path.exists(db_file)

# Function to create the database and table for license plates
def create_license_plates_database():
    if not database_exists(LICENSE_PLATES_DB_FILE):
        conn = sqlite3.connect(LICENSE_PLATES_DB_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS license_plates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate_number TEXT NOT NULL
            )
        ''')
        conn.commit()
        conn.close()
        print(f"License plates database '{LICENSE_PLATES_DB_FILE}' created successfully.")
    else:
        print(f"License plates database '{LICENSE_PLATES_DB_FILE}' already exists. Using existing database.")

# Function to create the database and table for used plates
def create_used_plates_database():
    # Force recreation of the used_plates database to ensure schema is up-to-date
    if database_exists(USED_PLATES_DB_FILE):
        try:
            os.remove(USED_PLATES_DB_FILE)
            print(f" பழைய '{USED_PLATES_DB_FILE}' database deleted to recreate with updated schema.")
        except OSError as e:
            print(f"Error deleting பழைய '{USED_PLATES_DB_FILE}' database: {e}")

    if not database_exists(USED_PLATES_DB_FILE):
        conn = sqlite3.connect(USED_PLATES_DB_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS used_plates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate_number TEXT NOT NULL,
                usage_count INTEGER NOT NULL DEFAULT 0,
                last_used_date DATE
            )
        ''')
        conn.commit()
        conn.close()
        print(f"Used plates database '{USED_PLATES_DB_FILE}' created successfully.")
    else:
        print(f"Used plates database '{USED_PLATES_DB_FILE}' already exists. Using existing database.")

# Function to add a license plate to the license_plates database
def add_license_plate_to_db(plate_number): # Renamed to avoid confusion
    conn = sqlite3.connect(LICENSE_PLATES_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('INSERT INTO license_plates (plate_number) VALUES (?)', (plate_number,))
    conn.commit()
    conn.close()
    print(f"License plate {plate_number} added to the license plates database.")

# Function to add/update a used plate in the used_plates database with date check
def add_used_plate_to_db(plate_number): # Renamed to avoid confusion
    conn = sqlite3.connect(USED_PLATES_DB_FILE)
    cursor = conn.cursor()
    today = date.today()
    cursor.execute('SELECT last_used_date FROM used_plates WHERE plate_number = ?', (plate_number,))
    result = cursor.fetchone()
    if result:
        last_used_date_str = result[0]
        if last_used_date_str: # Check if last_used_date is not None in DB
            last_used_date = date.fromisoformat(last_used_date_str)
            if last_used_date == today:
                print(f"License plate {plate_number} already used today.")
                conn.close()
                return False # Already used today, do not update and return False
    cursor.execute('INSERT OR IGNORE INTO used_plates (plate_number, usage_count, last_used_date) VALUES (?, 0, ?)', (plate_number, today))
    cursor.execute('UPDATE used_plates SET usage_count = usage_count + 1, last_used_date = ? WHERE plate_number = ?', (today, plate_number))
    conn.commit()
    conn.close()
    print(f"License plate {plate_number} usage count updated in used plates database for {today}.")
    return True # Successfully updated, return True


# Function to check if a license plate exists in the license_plates database
def license_plate_exists(plate_number):
    conn = sqlite3.connect(LICENSE_PLATES_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('SELECT 1 FROM license_plates WHERE plate_number LIKE ?', (plate_number[:5] + '%',))
    exists = cursor.fetchone() is not None
    conn.close()
    return exists

# Function to check if a license plate is used today in used_plates database
def is_license_plate_used_today(plate_number): # Renamed for clarity
    conn = sqlite3.connect(USED_PLATES_DB_FILE)
    cursor = conn.cursor()
    today = date.today()
    cursor.execute('SELECT last_used_date FROM used_plates WHERE plate_number LIKE ?', (plate_number[:5] + '%',))
    result = cursor.fetchone()
    conn.close()
    if result and result[0]:
        last_used_date = date.fromisoformat(result[0])
        return last_used_date == today
    return False

# Function to delete a license plate from license_plates database
def delete_license_plate_from_db(plate_number):
    conn = sqlite3.connect(LICENSE_PLATES_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM license_plates WHERE plate_number = ?', (plate_number,))
    conn.commit()
    conn.close()
    print(f"License plate {plate_number} deleted from license plates database.")

# Function to delete a license plate from used_plates database
def delete_used_plate_from_db(plate_number):
    conn = sqlite3.connect(USED_PLATES_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM used_plates WHERE plate_number = ?', (plate_number,))
    conn.commit()
    conn.close()
    print(f"License plate {plate_number} deleted from used plates database.")


# Function to open the command prompt
def open_command_prompt():
    subprocess.Popen('ls')
    subprocess.Popen(['python', 'open.py'], executable='python3')

def create_gui():
    global img_roi
    img_roi = None
    last_recognized_plate = None
    command_scheduled = False

    # Create the databases and tables (ensure schema is up-to-date)
    create_license_plates_database()
    create_used_plates_database()

    def submit_plate():
        plate_number = entry.get().upper()
        if license_plate_exists(plate_number):
            if is_license_plate_used_today(plate_number):
                messagebox.showinfo("Info", f"License plate {plate_number} has already been used today!")
            else:
                if add_used_plate_to_db(plate_number): # Add to used plates if not already used today
                    messagebox.showinfo("Success", f"License plate {plate_number} added to used plates and marked as used today!")
                else:
                     messagebox.showinfo("Info", f"License plate {plate_number} already used today (manual add).")
        else:
            add_license_plate_to_db(plate_number) # Add to license plates db first
            if add_used_plate_to_db(plate_number): # Then add to used plates and mark as used today
                messagebox.showinfo("Success", f"License plate {plate_number} added successfully to both databases and marked as used today!")
            else:
                 messagebox.showinfo("Info", f"License plate {plate_number} added to license plates but not marked as used today (error).")

    def delete_plate():
        plate_number_to_delete = delete_entry.get().upper()
        if license_plate_exists(plate_number_to_delete):
            delete_license_plate_from_db(plate_number_to_delete)
            delete_used_plate_from_db(plate_number_to_delete)
            messagebox.showinfo("Success", f"License plate {plate_number_to_delete} deleted from databases.")
        else:
            messagebox.showinfo("Info", f"License plate {plate_number_to_delete} not found in license plates database.")


    def save_plate():
        global count, img_roi
        if img_roi is not None:
            filename = os.path.join(SAVE_FOLDER, f"scaned_img_{count}.jpg")
            cv2.imwrite(filename, img_roi)
            messagebox.showinfo("Success", f"Plate saved as {filename}")
            count += 1
        else:
            messagebox.showinfo("Info", "No license plate detected to save.")

    root = tk.Tk()
    root.title("License Plate Recognition")

    # Label to display the video feed
    video_label = tk.Label(root)
    video_label.pack()

    label = tk.Label(root, text="Enter License Plate Number to Add:")
    label.pack(pady=10)

    entry = tk.Entry(root)
    entry.pack(pady=10)

    submit_button = tk.Button(root, text="Submit", command=submit_plate)
    submit_button.pack(pady=10)

    label_delete = tk.Label(root, text="Enter License Plate Number to Delete:")
    label_delete.pack(pady=10)

    delete_entry = tk.Entry(root)
    delete_entry.pack(pady=10)

    delete_button = tk.Button(root, text="Delete Plate", command=delete_plate)
    delete_button.pack(pady=10)


    save_button = tk.Button(root, text="Save Plate", command=save_plate)
    save_button.pack(pady=10)

    def delayed_command(plate_number):
        print(f"Sending delayed command for plate: {plate_number}")
        open_command_prompt()
        global command_scheduled
        command_scheduled = False  # Reset the flag after sending the command

    def update_frame():
        global img_roi, last_recognized_plate, command_scheduled
        success, img_np = cap.read()
        if not success or img_np is None:
            print("Error: Failed to capture frame.")
            video_label.after(10, update_frame)  # Try again later
            return

        plate_cascade = cv2.CascadeClassifier(harcascade)

        if plate_cascade.empty():
            print(f"Error: Could not load Haar cascade classifier at: {harcascade}")
            return

        img_gray = cv2.cvtColor(img_np, cv2.COLOR_BGR2GRAY)

        if img_gray is None or img_gray.size == 0:
            print("Error: Grayscale image is empty.")
            video_label.after(10, update_frame)
            return

        plates = plate_cascade.detectMultiScale(img_gray, 1.1, 4)

        img_roi = None

        for (x, y, w, h) in plates:
            area = w * h
            if area > min_area:
                cv2.rectangle(img_np, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(img_np, "Hello Number", (x, y-5), cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.7, (255, 0, 255), 2)
                img_roi = img_np[y: y+h, x:x+w]

                results = reader.readtext(img_roi)
                for (bbox, text, prob) in results:
                    detected_text = text.upper()
                    print(f"Detected text: {detected_text} with probability: {prob}")
                    if license_plate_exists(detected_text):
                        if not is_license_plate_used_today(detected_text):
                            print(f"License plate {detected_text} exists and not used today. Executing command.")
                            open_command_prompt()
                            if add_used_plate_to_db(detected_text): # Only add to used plates and proceed if successful update
                                pass # Command executed and usage updated
                            else:
                                print(f"Failed to update usage for {detected_text}, might have been used in a parallel process just now.")
                        else:
                            print(f"Command for license plate {detected_text} already executed today.")

        cv2image = cv2.cvtColor(img_np, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(cv2image)
        imgtk = ImageTk.PhotoImage(image=img)
        video_label.config(image=imgtk)
        video_label.imgtk = imgtk
        video_label.after(10, update_frame) # Update every 10 milliseconds

    update_frame()
    root.mainloop()

# Function to reset the used plates database including dates
def reset_used_plates_database():
    conn = sqlite3.connect(USED_PLATES_DB_FILE) # Use USED_PLATES_DB_FILE here
    cursor = conn.cursor()
    cursor.execute('DELETE FROM used_plates')
    conn.commit()
    conn.close()
    print("Used plates database reset successfully.")

# Register the reset function to be called at exit
atexit.register(reset_used_plates_database)

# Create the databases and tables
create_license_plates_database()
create_used_plates_database()

# Run the GUI on the main thread
create_gui()

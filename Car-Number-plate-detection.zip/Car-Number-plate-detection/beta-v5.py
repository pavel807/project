import cv2
import easyocr
import sqlite3
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import subprocess
import atexit
import os
import time
import threading  # Import the threading module
import queue # Import queue module

# Путь к папке для сохранения изображений
SAVE_FOLDER = "plates"
if not os.path.exists(SAVE_FOLDER):
    os.makedirs(SAVE_FOLDER)

# Path to the Haar Cascade classifier XML file for license plate detection
harcascade = "/Users/pavellabusev/Downloads/Car-Number-plate-detection/model/haarcascade_russian_plate_number.xml"

# Function to find the first available camera
def find_available_camera():
    for i in range(10):
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            print(f"Camera {i} is available.")
            return cap
        cap.release()
    print("No available cameras found.")
    return None

# Accessing the first available camera
cap = find_available_camera()

if cap is None:
    print("No cameras found. Exiting.")
    exit()

# Setting the dimensions for the video stream
cap.set(3, 640)  # width - Adjusted for Tkinter window
cap.set(4, 480)  # height - Adjusted for Tkinter window

# Minimum area for a detected region to be considered a license plate
min_area = 70
count = 0

# Initialize the EasyOCR reader
reader = easyocr.Reader(['en'])

# Database file names
LICENSE_PLATES_DB_FILE = 'license_plates.db'
USED_PLATES_DB_FILE = 'used_plates.db'
SCEN_DB_FILE = 'scen.db'  # New database file name

# Function to check if a database file exists
def database_exists(db_file):
    return os.path.exists(db_file)

# Function to create the database and table for license plates
def create_license_plates_database():
    if not database_exists(LICENSE_PLATES_DB_FILE):
        conn = sqlite3.connect(LICENSE_PLATES_DB_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS license_plates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate_number TEXT NOT NULL
            )
        ''')
        conn.commit()
        conn.close()
        print(f"License plates database '{LICENSE_PLATES_DB_FILE}' created successfully.")
    else:
        print(f"License plates database '{LICENSE_PLATES_DB_FILE}' already exists. Using existing database.")

# Function to create the database and table for used plates
def create_used_plates_database():
    if not database_exists(USED_PLATES_DB_FILE):
        conn = sqlite3.connect(USED_PLATES_DB_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS used_plates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate_number TEXT NOT NULL,
                usage_count INTEGER NOT NULL DEFAULT 0
            )
        ''')
        conn.commit()
        conn.close()
        print(f"Used plates database '{USED_PLATES_DB_FILE}' created successfully.")
    else:
        print(f"Used plates database '{USED_PLATES_DB_FILE}' already exists. Using existing database.")

# Function to create the database and table for scen data
def create_scen_database():
    if not database_exists(SCEN_DB_FILE):
        conn = sqlite3.connect(SCEN_DB_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS scen_table (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate_number TEXT NOT NULL,
                scenario_id INTEGER NOT NULL
            )
        ''')
        conn.commit()
        conn.close()
        print(f"Scen database '{SCEN_DB_FILE}' created successfully.")
    else:
        print(f"Scen database '{SCEN_DB_FILE}' already exists. Using existing database.")

# Function to add a license plate to the license plates database
def add_license_plate(plate_number):
    conn = sqlite3.connect(LICENSE_PLATES_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('INSERT INTO license_plates (plate_number) VALUES (?)', (plate_number,))
    conn.commit()
    conn.close()
    print(f"License plate {plate_number} added to the license plates database.")

# Function to add/update a used plate in the used plates database
def add_used_plate(plate_number):
    conn = sqlite3.connect(USED_PLATES_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('INSERT OR IGNORE INTO used_plates (plate_number, usage_count) VALUES (?, 0)', (plate_number,))
    cursor.execute('UPDATE used_plates SET usage_count = usage_count + 1 WHERE plate_number = ?', (plate_number,))
    conn.commit()
    conn.close()
    print(f"License plate {plate_number} usage count updated in used plates database.")

# Modified function to add a license plate and CYCLIC scenario ID to the scen database
def add_scen_plate(plate_number): # Removed scenario_id parameter from function definition
    conn = sqlite3.connect(SCEN_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('SELECT COUNT(*) FROM scen_table') # Get current count of rows
    count = cursor.fetchone()[0] # Fetch the count
    cyclic_scenario_id = (count % 3) + 1 # Calculate cyclic scenario ID (1, 2, 3, 1, 2, 3...)
    cursor.execute('INSERT INTO scen_table (plate_number, scenario_id) VALUES (?, ?)', (plate_number, cyclic_scenario_id))
    conn.commit()
    conn.close()
    print(f"License plate {plate_number} with CYCLIC scenario ID {cyclic_scenario_id} added to scen database.")

# Function to get scenario ID for a license plate from scen database
def get_scenario_for_plate(plate_number):
    conn = sqlite3.connect(SCEN_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('SELECT scenario_id FROM scen_table WHERE plate_number = ?', (plate_number,))
    result = cursor.fetchone()
    conn.close()
    if result:
        return result[0]
    return None

# Function to check if a license plate exists in the license plates database
def license_plate_exists(plate_number):
    conn = sqlite3.connect(LICENSE_PLATES_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('SELECT 1 FROM license_plates WHERE plate_number LIKE ?', (plate_number[:5] + '%',))
    exists = cursor.fetchone() is not None
    conn.close()
    return exists

# Function to check if a license plate is used (count > 0)
def license_plate_used(plate_number):
    conn = sqlite3.connect(USED_PLATES_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('SELECT usage_count FROM used_plates WHERE plate_number LIKE ?', (plate_number[:5] + '%',))
    result = cursor.fetchone()
    conn.close()
    return result is not None and result[0] > 0

# Function to open the command prompt
def open_command_prompt():
    subprocess.Popen('cmd.exe')

# Function to open another command prompt (cmd1.exe - placeholder)
def open_command_prompt_1():
    try:
        subprocess.Popen('cmd1.exe') # Replace 'cmd1.exe' with actual command if needed
        print("Executing command: cmd1.exe (Placeholder)")
    except FileNotFoundError:
        print("Warning: cmd1.exe not found or is not executable.")

# Function to open another command prompt (cmd2.exe - placeholder)
def open_command_prompt_2():
    try:
        subprocess.Popen('cmd2.exe') # Replace 'cmd2.exe' with actual command if needed
        print("Executing command: cmd2.exe (Placeholder)")
    except FileNotFoundError:
        print("Warning: cmd2.exe not found or is not executable.")

def execute_scenario_threaded(scenario_id): # Modified to run in a thread
    """Executes the scenario in a separate thread to prevent blocking."""
    def run_scenario(): # Inner function to actually execute commands
        if scenario_id == 1:
            open_command_prompt()
        elif scenario_id == 2:
            open_command_prompt()
            open_command_prompt_1()
        elif scenario_id == 3:
            open_command_prompt_2()
            open_command_prompt()
        else:
            print(f"Unknown scenario ID: {scenario_id}")
    thread = threading.Thread(target=run_scenario) # Create a new thread
    thread.daemon = True # Set as daemon thread so it exits when main thread exits
    thread.start() # Start the thread

# No changes to open_command_prompt, open_command_prompt_1, open_command_prompt_2, just execute_scenario_threaded will be used

def create_gui():
    global img_roi
    img_roi = None
    last_recognized_plate = None
    command_scheduled = False

    # Create the databases and tables (ensure schema is up-to-date)
    create_license_plates_database()
    create_used_plates_database()
    create_scen_database()  # Create the new scen database

    ocr_queue = queue.Queue() # Создаем очередь для результатов OCR

    def process_ocr(roi_image): # Функция для OCR в отдельном потоке
        start_time = time.time()
        results = reader.readtext(roi_image)
        end_time = time.time()
        ocr_time = end_time - start_time
        print(f"OCR Thread time: {ocr_time:.4f} seconds")
        ocr_queue.put(results) # Помещаем результаты в очередь

    def submit_plate(): # Submit to license_plates database
        plate_number = entry_plate.get().upper()
        if license_plate_exists(plate_number):
            messagebox.showinfo("Info", f"License plate {plate_number} already exists in the main database!")
        elif license_plate_used(plate_number):
            messagebox.showinfo("Info", f"License plate {plate_number} has already been used!")
        else:
            add_license_plate(plate_number)
            add_used_plate(plate_number)
            messagebox.showinfo("Success", f"License plate {plate_number} added to the main database successfully!")
        entry_plate.delete(0, tk.END) # Clear entry field after submission

    def submit_scen_plate(): # Submit to scen database with cyclic ID
        scen_plate_number = entry_scen_plate.get().upper()

        add_scen_plate(scen_plate_number) # Add to scen DB with automatic cyclic ID
        messagebox.showinfo("Success", f"License plate {scen_plate_number} added to scen database with cyclic Scenario ID!")
        entry_scen_plate.delete(0, tk.END) # Clear entry field

    def save_plate():
        global count, img_roi
        if img_roi is not None:
            filename = os.path.join(SAVE_FOLDER, f"scaned_img_{count}.jpg")
            cv2.imwrite(filename, img_roi)
            messagebox.showinfo("Success", f"Plate saved as {filename}")
            count += 1
        else:
            messagebox.showinfo("Info", "No license plate detected to save.")

    root = tk.Tk()
    root.title("License Plate Recognition")

    # Label to display the video feed
    video_label = tk.Label(root)
    video_label.pack()

    # --- Section for Main License Plate Database ---
    frame_main_db = tk.Frame(root)
    frame_main_db.pack(pady=10)

    label_plate = tk.Label(frame_main_db, text="Enter License Plate for Main DB:")
    label_plate.pack()
    entry_plate = tk.Entry(frame_main_db)
    entry_plate.pack()
    submit_button_plate = tk.Button(frame_main_db, text="Submit to Main DB", command=submit_plate)
    submit_button_plate.pack()

    # --- Section for Scen Database ---
    frame_scen_db = tk.Frame(root)
    frame_scen_db.pack(pady=10)

    label_scen_plate = tk.Label(frame_scen_db, text="Enter Plate for Scen DB:")
    label_scen_plate.pack()
    entry_scen_plate = tk.Entry(frame_scen_db)
    entry_scen_plate.pack()

    submit_button_scen = tk.Button(frame_scen_db, text="Submit to Scen DB", command=submit_scen_plate)
    submit_button_scen.pack()

    save_button = tk.Button(root, text="Save Plate Image", command=save_plate)
    save_button.pack(pady=10)

    def update_frame():
        global img_roi, last_recognized_plate, command_scheduled
        success, img_np = cap.read()
        if not success or img_np is None:
            print("Error: Failed to capture frame.")
            video_label.after(10, update_frame)  # Try again later
            return

        plate_cascade = cv2.CascadeClassifier(harcascade)

        if plate_cascade.empty():
            print(f"Error: Could not load Haar cascade classifier at: {harcascade}")
            return

        img_gray = cv2.cvtColor(img_np, cv2.COLOR_BGR2GRAY)

        if img_gray is None or img_gray.size == 0:
            print("Error: Grayscale image is empty.")
            video_label.after(10, update_frame)
            return

        plates = plate_cascade.detectMultiScale(img_gray, 1.1, 4)

        img_roi = None

        for (x, y, w, h) in plates:
            area = w * h
            if area > min_area:
                cv2.rectangle(img_np, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(img_np, "Hello Number", (x, y-5), cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.7, (255, 0, 255), 2)
                img_roi = img_np[y: y+h, x:x+w]

                if img_roi is not None:  # Check if img_roi is valid before starting OCR thread
                    threading.Thread(target=process_ocr, args=(img_roi,), daemon=True).start() # Запускаем OCR в потоке

        try: # Проверяем очередь на наличие результатов OCR (неблокирующий вызов)
            results = ocr_queue.get_nowait() # Получаем результаты из очереди, если есть
            if results: # Если результаты получены
                for (bbox, text, prob) in results:
                    detected_text_from_ocr = text.upper() # Используем другую переменную для ясности
                    print(f"Detected text (from thread): {detected_text_from_ocr} with probability: {prob}")
                    if license_plate_exists(detected_text_from_ocr): # Используем полученный текст
                        conn = sqlite3.connect(USED_PLATES_DB_FILE)
                        cursor = conn.cursor()
                        cursor.execute('SELECT usage_count FROM used_plates WHERE plate_number = ?', (detected_text_from_ocr,))
                        result = cursor.fetchone()
                        conn.close()
                        if result is None or result[0] == 0:
                            scenario_id = get_scenario_for_plate(detected_text_from_ocr)
                            if scenario_id:
                                print(f"License plate {detected_text_from_ocr} exists in scen DB with Scenario ID: {scenario_id}. Executing scenario in thread.")
                                execute_scenario_threaded(scenario_id)
                            else:
                                print(f"License plate {detected_text_from_ocr} exists in main DB, no scenario defined, executing default command.")
                                open_command_prompt()

                            add_used_plate(detected_text_from_ocr)
                        else:
                            print(f"Command for license plate {detected_text_from_ocr} already executed in this session.")
        except queue.Empty: # Если очередь пуста, результатов OCR еще нет
            pass # Ничего не делаем, ждем следующий кадр и возможные результаты

        cv2image = cv2.cvtColor(img_np, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(cv2image)
        imgtk = ImageTk.PhotoImage(image=img)
        video_label.config(image=imgtk)
        video_label.imgtk = imgtk
        video_label.after(10, update_frame) # Update every 10 milliseconds

    update_frame()
    root.mainloop()

# Function to reset the used plates database
def reset_used_plates_database():
    conn = sqlite3.connect(USED_PLATES_DB_FILE) # Use USED_PLATES_DB_FILE here
    cursor = conn.cursor()
    cursor.execute('DELETE FROM used_plates')
    conn.commit()
    conn.close()
    print("Used plates database reset successfully.")

# Function to reset the scen database
def reset_scen_database():
    conn = sqlite3.connect(SCEN_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM scen_table')
    conn.commit()
    conn.close()
    print("Scen database reset successfully.")

# Register the reset function to be called at exit (register both reset functions)
atexit.register(reset_used_plates_database)
atexit.register(reset_scen_database)

# Create the databases and tables
create_license_plates_database()
create_used_plates_database()
create_scen_database() # Create the new scen database

# Run the GUI on the main thread
create_gui()

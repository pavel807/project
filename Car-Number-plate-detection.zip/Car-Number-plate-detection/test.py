import sqlite3
import sys

# Function to create the database and table
def create_database():
    conn = sqlite3.connect('license_plates.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS license_plates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            plate_number TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()
    print("Database and table created successfully.")

# Function to add a license plate to the database
def add_license_plate(plate_number):
    conn = sqlite3.connect('license_plates.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO license_plates (plate_number) VALUES (?)', (plate_number,))
    conn.commit()
    conn.close()
    print(f"License plate {plate_number} added to the database.")

# Function to check if a license plate exists in the database
def license_plate_exists(plate_number):
    conn = sqlite3.connect('license_plates.db')
    cursor = conn.cursor()
    cursor.execute('SELECT 1 FROM license_plates WHERE plate_number = ?', (plate_number,))
    exists = cursor.fetchone() is not None
    conn.close()
    return exists

# Main function to handle command-line arguments
def main():
    if len(sys.argv) != 2:
        print("Usage: python add_license_plate.py <plate_number>")
        return

    plate_number = sys.argv[1].upper()

    # Create the database and table if they don't exist
    create_database()

    # Check if the license plate already exists in the database
    if license_plate_exists(plate_number):
        print(f"License plate {plate_number} already exists in the database.")
    else:
        add_license_plate(plate_number)

if __name__ == "__main__":
    main()

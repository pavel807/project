import cv2

# Исправьте путь к файлу, если это необходимо
file_path = 'C:/Users/pavel/Car-Number-plate-detection/model/haarcascade_russian_plate_number.xml'

# Загрузите каскад
plate_cascade = cv2.CascadeClassifier(file_path)

# Проверьте, успешно ли загружен каскад
if plate_cascade.empty():
    raise IOError(f"Не удалось загрузить каскадный классификатор из {file_path}")

# Загрузите изображение
img = cv2.imread('car_image.png')
img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Обнаружение номеров
plates = plate_cascade.detectMultiScale(img_gray, 1.1, 4)

# Нарисуйте прямоугольники вокруг обнаруженных номеров
for (x, y, w, h) in plates:
    cv2.rectangle(img, (x, y), (x+w, y+h), (255, 0, 0), 2)

# Отобразите результат
cv2.imshow('Обнаруженные номера', img)
cv2.waitKey(0)
cv2.destroyAllWindows()

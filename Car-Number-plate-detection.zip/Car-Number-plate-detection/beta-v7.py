import cv2
import easyocr
import sqlite3
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import subprocess
import atexit
import os
import time
from datetime import date
from flask import Flask, request, jsonify
import threading

# Server setup
app = Flask(__name__)

# Путь к папке для сохранения изображений
SAVE_FOLDER = "plates"
if not os.path.exists(SAVE_FOLDER):
    os.makedirs(SAVE_FOLDER)

# Path to the Haar Cascade classifier XML file for license plate detection
harcascade = "/Users/pavellabusev/Car-Number-plate-detection/model/haarcascade_russian_plate_number.xml"

# Database file names
LICENSE_PLATES_DB_FILE = 'license_plates.db'
USED_PLATES_DB_FILE = 'used_plates.db'
TEMPORARY_PASS_DB_FILE = 'temporary_passes.db'

# Flask API endpoints
@app.route('/add_license_plate', methods=['POST'])
def add_license_plate():
    data = request.json
    plate_number = data.get('plate_number')
    if not plate_number:
        return jsonify({'error': 'Missing plate number'}), 400
    add_license_plate_to_db(plate_number)
    return jsonify({'message': f'License plate {plate_number} added'}), 200

@app.route('/delete_license_plate', methods=['DELETE'])
def delete_license_plate():
    data = request.json
    plate_number = data.get('plate_number')
    if not plate_number:
        return jsonify({'error': 'Missing plate number'}), 400
    delete_license_plate_from_db(plate_number)
    return jsonify({'message': f'License plate {plate_number} deleted'}), 200

@app.route('/add_used_plate', methods=['POST'])
def add_used_plate():
    data = request.json
    plate_number = data.get('plate_number')
    if not plate_number:
        return jsonify({'error': 'Missing plate number'}), 400
    if add_used_plate_to_db(plate_number):
        return jsonify({'message': f'License plate {plate_number} marked as used'}), 200
    return jsonify({'error': f'License plate {plate_number} already used today'}), 400

@app.route('/delete_used_plate', methods=['DELETE'])
def delete_used_plate():
    data = request.json
    plate_number = data.get('plate_number')
    if not plate_number:
        return jsonify({'error': 'Missing plate number'}), 400
    delete_used_plate_from_db(plate_number)
    return jsonify({'message': f'Used record for {plate_number} deleted'}), 200

@app.route('/add_temporary_pass', methods=['POST'])
def add_temporary_pass():
    data = request.json
    plate_number = data.get('plate_number')
    expiration_time = data.get('expiration_time')  # Время в секундах Unix timestamp
    if not plate_number or not expiration_time:
        return jsonify({'error': 'Missing plate number or expiration time'}), 400

    created_at = int(time.time())
    conn = sqlite3.connect(TEMPORARY_PASS_DB_FILE)
    cursor = conn.cursor()
    cursor.execute(
        'INSERT INTO temporary_passes (plate_number, expiration_time, created_at) VALUES (?, ?, ?)',
        (plate_number, expiration_time, created_at)
    )
    conn.commit()
    conn.close()
    return jsonify({'message': f"Temporary pass for {plate_number} added with expiration time {expiration_time}"}), 200

@app.route('/delete_temporary_pass', methods=['DELETE'])
def delete_temporary_pass():
    data = request.json
    plate_number = data.get('plate_number')
    if not plate_number:
        return jsonify({'error': 'Missing plate number'}), 400

    conn = sqlite3.connect(TEMPORARY_PASS_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM temporary_passes WHERE plate_number = ?', (plate_number,))
    conn.commit()
    conn.close()
    return jsonify({'message': f"Temporary pass for {plate_number} deleted"}), 200

# Function to start the Flask server in a separate thread
def start_server():
    app.run(host='0.0.0.0', port=5000, use_reloader=False)

# Start the server in a background thread
server_thread = threading.Thread(target=start_server, daemon=True)
server_thread.start()

# Existing functions and GUI code...

# Function to find the first available camera
def find_available_camera():
    for i in range(10):
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            print(f"Camera {i} is available.")
            return cap
        cap.release()
    print("No available cameras found.")
    return None

# Accessing the first available camera
cap = find_available_camera()

if cap is None:
    print("No cameras found. Exiting.")
    exit()

# Setting the dimensions for the video stream
cap.set(3, 640)  # width - Adjusted for Tkinter window
cap.set(4, 480)  # height - Adjusted for Tkinter window

# Minimum area for a detected region to be considered a license plate
min_area = 70
count = 0

# Initialize the EasyOCR reader
reader = easyocr.Reader(['en'])

# Function to check if a database file exists
def database_exists(db_file):
    return os.path.exists(db_file)

# Function to create the database and table for license plates
def create_license_plates_database():
    if not database_exists(LICENSE_PLATES_DB_FILE):
        conn = sqlite3.connect(LICENSE_PLATES_DB_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS license_plates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate_number TEXT NOT NULL
            )
        ''')
        conn.commit()
        conn.close()
        print(f"License plates database '{LICENSE_PLATES_DB_FILE}' created successfully.")
    else:
        print(f"License plates database '{LICENSE_PLATES_DB_FILE}' already exists. Using existing database.")

# Function to create the database and table for used plates
def create_used_plates_database():
    if not database_exists(USED_PLATES_DB_FILE):
        conn = sqlite3.connect(USED_PLATES_DB_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS used_plates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate_number TEXT NOT NULL,
                usage_count INTEGER NOT NULL DEFAULT 0,
                last_used_date DATE
            )
        ''')
        conn.commit()
        conn.close()
        print(f"Used plates database '{USED_PLATES_DB_FILE}' created successfully.")
    else:
        print(f"Used plates database '{USED_PLATES_DB_FILE}' already exists. Using existing database.")

# Function to create the database and table for temporary passes
def create_temporary_passes_database():
    if not database_exists(TEMPORARY_PASS_DB_FILE):
        conn = sqlite3.connect(TEMPORARY_PASS_DB_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS temporary_passes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate_number TEXT NOT NULL,
                expiration_time INTEGER NOT NULL,
                created_at INTEGER NOT NULL
            )
        ''')
        conn.commit()
        conn.close()
        print(f"Temporary passes database '{TEMPORARY_PASS_DB_FILE}' created successfully.")
    else:
        print(f"Temporary passes database '{TEMPORARY_PASS_DB_FILE}' already exists. Using existing database.")

# Function to add a license plate to the license_plates database
def add_license_plate_to_db(plate_number):
    conn = sqlite3.connect(LICENSE_PLATES_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('INSERT INTO license_plates (plate_number) VALUES (?)', (plate_number,))
    conn.commit()
    conn.close()
    print(f"License plate {plate_number} added to the license plates database.")

# Function to add/update a used plate in the used_plates database with date check
def add_used_plate_to_db(plate_number):
    conn = sqlite3.connect(USED_PLATES_DB_FILE)
    cursor = conn.cursor()
    today = date.today()
    cursor.execute('SELECT last_used_date FROM used_plates WHERE plate_number = ?', (plate_number,))
    result = cursor.fetchone()
    if result:
        last_used_date_str = result[0]
        if last_used_date_str:
            last_used_date = date.fromisoformat(last_used_date_str)
            if last_used_date == today:
                print(f"License plate {plate_number} already used today.")
                conn.close()
                return False
    cursor.execute('INSERT OR IGNORE INTO used_plates (plate_number, usage_count, last_used_date) VALUES (?, 0, ?)', (plate_number, today))
    cursor.execute('UPDATE used_plates SET usage_count = usage_count + 1, last_used_date = ? WHERE plate_number = ?', (today, plate_number))
    conn.commit()
    conn.close()
    print(f"License plate {plate_number} usage count updated in used plates database for {today}.")
    return True

# Function to check if a license plate exists in the license_plates database
def license_plate_exists(plate_number):
    conn = sqlite3.connect(LICENSE_PLATES_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('SELECT 1 FROM license_plates WHERE plate_number LIKE ?', (plate_number[:5] + '%',))
    exists = cursor.fetchone() is not None
    conn.close()
    return exists

# Function to check if a license plate is used today in used_plates database
def is_license_plate_used_today(plate_number):
    conn = sqlite3.connect(USED_PLATES_DB_FILE)
    cursor = conn.cursor()
    today = date.today()
    cursor.execute('SELECT last_used_date FROM used_plates WHERE plate_number LIKE ?', (plate_number[:5] + '%',))
    result = cursor.fetchone()
    conn.close()
    if result and result[0]:
        last_used_date = date.fromisoformat(result[0])
        return last_used_date == today
    return False

# Function to check if a temporary pass is active
def check_temporary_pass(plate_number):
    conn = sqlite3.connect(TEMPORARY_PASS_DB_FILE)
    cursor = conn.cursor()
    current_time = int(time.time())
    cursor.execute('SELECT plate_number FROM temporary_passes WHERE plate_number = ? AND expiration_time > ?', (plate_number, current_time))
    result = cursor.fetchone()
    conn.close()
    return result is not None

# Function to delete a license plate from license_plates database
def delete_license_plate_from_db(plate_number):
    conn = sqlite3.connect(LICENSE_PLATES_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM license_plates WHERE plate_number = ?', (plate_number,))
    conn.commit()
    conn.close()
    print(f"License plate {plate_number} deleted from license plates database.")

# Function to delete a license plate from used_plates database
def delete_used_plate_from_db(plate_number):
    conn = sqlite3.connect(USED_PLATES_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM used_plates WHERE plate_number = ?', (plate_number,))
    conn.commit()
    conn.close()
    print(f"License plate {plate_number} deleted from used plates database.")

# Function to open the command prompt
def open_command_prompt():
    subprocess.Popen(['python', 'open.py'], executable='python3')

def create_gui():
    global img_roi
    img_roi = None
    last_recognized_plate = None
    command_scheduled = False

    create_license_plates_database()
    create_used_plates_database()
    create_temporary_passes_database()

    def submit_plate():
        plate_number = entry.get().upper()
        if license_plate_exists(plate_number) or check_temporary_pass(plate_number):
            if is_license_plate_used_today(plate_number):
                messagebox.showinfo("Info", f"License plate {plate_number} has already been used today!")
            else:
                if add_used_plate_to_db(plate_number):
                    messagebox.showinfo("Success", f"License plate {plate_number} added to used plates and marked as used today!")
                else:
                    messagebox.showinfo("Info", f"License plate {plate_number} already used today (manual add).")
        else:
            add_license_plate_to_db(plate_number)
            if add_used_plate_to_db(plate_number):
                messagebox.showinfo("Success", f"License plate {plate_number} added successfully to both databases and marked as used today!")
            else:
                messagebox.showinfo("Info", f"License plate {plate_number} added to license plates but not marked as used today (error).")

    def delete_plate():
        plate_number_to_delete = delete_entry.get().upper()
        if license_plate_exists(plate_number_to_delete):
            delete_license_plate_from_db(plate_number_to_delete)
            delete_used_plate_from_db(plate_number_to_delete)
            messagebox.showinfo("Success", f"License plate {plate_number_to_delete} deleted from databases.")
        else:
            messagebox.showinfo("Info", f"License plate {plate_number_to_delete} not found in license plates database.")

    def save_plate():
        global count, img_roi
        if img_roi is not None:
            filename = os.path.join(SAVE_FOLDER, f"scanned_img_{count}.jpg")
            cv2.imwrite(filename, img_roi)
            messagebox.showinfo("Success", f"Plate saved as {filename}")
            count += 1
        else:
            messagebox.showinfo("Info", "No license plate detected to save.")

    def update_frame():
        global img_roi, last_recognized_plate, command_scheduled
        success, img_np = cap.read()
        if not success or img_np is None:
            print("Error: Failed to capture frame.")
            video_label.after(10, update_frame)
            return

        plate_cascade = cv2.CascadeClassifier(harcascade)

        if plate_cascade.empty():
            print(f"Error: Could not load Haar cascade classifier at: {harcascade}")
            return

        img_gray = cv2.cvtColor(img_np, cv2.COLOR_BGR2GRAY)

        if img_gray is None or img_gray.size == 0:
            print("Error: Grayscale image is empty.")
            video_label.after(10, update_frame)
            return

        plates = plate_cascade.detectMultiScale(img_gray, 1.1, 4)

        img_roi = None

        for (x, y, w, h) in plates:
            area = w * h
            if area > min_area:
                cv2.rectangle(img_np, (x, y), (x + w, y + h), (0, 255, 0), 2)
                cv2.putText(img_np, "Hello Number", (x, y - 5), cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.7, (255, 0, 255), 2)
                img_roi = img_np[y: y + h, x:x + w]

                results = reader.readtext(img_roi)
                for (bbox, text, prob) in results:
                    detected_text = text.upper()
                    print(f"Detected text: {detected_text} with probability: {prob}")
                    if license_plate_exists(detected_text) or check_temporary_pass(detected_text):
                        if not is_license_plate_used_today(detected_text):
                            print(f"License plate {detected_text} exists and not used today. Executing command.")
                            open_command_prompt()
                            if add_used_plate_to_db(detected_text):
                                pass
                            else:
                                print(f"Failed to update usage for {detected_text}, might have been used in a parallel process just now.")
                        else:
                            print(f"Command for license plate {detected_text} already executed today.")

        cv2image = cv2.cvtColor(img_np, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(cv2image)
        imgtk = ImageTk.PhotoImage(image=img)
        video_label.config(image=imgtk)
        video_label.imgtk = imgtk
        video_label.after(10, update_frame)

    root = tk.Tk()
    root.title("License Plate Recognition")

    video_label = tk.Label(root)
    video_label.pack()

    label = tk.Label(root, text="Enter License Plate Number to Add:")
    label.pack(pady=10)

    entry = tk.Entry(root)
    entry.pack(pady=10)

    submit_button = tk.Button(root, text="Submit", command=submit_plate)
    submit_button.pack(pady=10)

    label_delete = tk.Label(root, text="Enter License Plate Number to Delete:")
    label_delete.pack(pady=10)

    delete_entry = tk.Entry(root)
    delete_entry.pack(pady=10)

    delete_button = tk.Button(root, text="Delete Plate", command=delete_plate)
    delete_button.pack(pady=10)

    save_button = tk.Button(root, text="Save Plate", command=save_plate)
    save_button.pack(pady=10)

    update_frame()
    root.mainloop()

# Function to reset the used plates database including dates
def reset_used_plates_database():
    conn = sqlite3.connect(USED_PLATES_DB_FILE)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM used_plates')
    conn.commit()
    conn.close()
    print("Used plates database reset successfully.")

# Register the reset function to be called at exit
atexit.register(reset_used_plates_database)

# Create the databases and tables
create_license_plates_database()
create_used_plates_database()
create_temporary_passes_database()

# Run the GUI on the main thread
create_gui()
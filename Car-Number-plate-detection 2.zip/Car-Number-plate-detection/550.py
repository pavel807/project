import socket
import threading

# --- Параметры проброса порта ---
LOCAL_HOST = '0.0.0.0'  # Слушать на всех интерфейсах
LOCAL_PORT = 550        # Локальный порт, на который будут подключаться клиенты

REMOTE_HOST = 'localhost'  # Хост, куда перенаправляем трафик (например, localhost или IP-адрес)
# REMOTE_PORT больше не указывается явно, будет совпадать с LOCAL_PORT


def handle_client(client_socket, remote_host, remote_port):
    """
    Обрабатывает отдельное клиентское соединение.
    Устанавливает соединение с удаленным сервером и перенаправляет трафик в обе стороны.
    """
    remote_socket = None
    try:
        # 1. Установить соединение с удаленным сервером
        remote_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        remote_socket.connect((remote_host, remote_port))
        print(f"Соединение с удаленным сервером {remote_host}:{remote_port} установлено.")

        # 2. Запустить потоки для двустороннего перенаправления трафика

        # Функция для перенаправления данных от клиента к удаленному серверу
        def client_to_remote(client_sock, remote_sock):
            try:
                while True:
                    data = client_sock.recv(4096)
                    if not data:
                        break  # Клиент закрыл соединение
                    remote_sock.sendall(data)  # Отправить данные на удаленный сервер
            except Exception as e:
                print(f"Ошибка перенаправления от клиента к серверу: {e}")
            finally:
                shutdown_sockets(client_sock, remote_sock)

        # Функция для перенаправления данных от удаленного сервера к клиенту
        def remote_to_client(remote_sock, client_sock):
            try:
                while True:
                    data = remote_sock.recv(4096)
                    if not data:
                        break  # Удаленный сервер закрыл соединение
                    client_sock.sendall(data)  # Отправить данные клиенту
            except Exception as e:
                print(f"Ошибка перенаправления от сервера к клиенту: {e}")
            finally:
                shutdown_sockets(remote_sock, client_sock)

        # Запуск потоков перенаправления
        client_to_remote_thread = threading.Thread(target=client_to_remote, args=(client_socket, remote_socket))
        remote_to_client_thread = threading.Thread(target=remote_to_client, args=(remote_socket, client_socket))

        client_to_remote_thread.daemon = True  # Поток завершится при завершении основной программы
        remote_to_client_thread.daemon = True  # Поток завершится при завершении основной программы

        client_to_remote_thread.start()
        remote_to_client_thread.start()

        # Ожидать завершения работы хотя бы одного потока (или основной поток может завершиться)
        client_to_remote_thread.join()
        remote_to_client_thread.join()

    except Exception as e:
        print(f"Ошибка при обработке клиента: {e}")
    finally:
        shutdown_sockets(client_socket, remote_socket)
        print("Соединение с клиентом и удаленным сервером закрыто.")


def shutdown_sockets(*sockets):
    """Закрывает все переданные сокеты."""
    for sock in sockets:
        if sock:
            try:
                sock.shutdown(socket.SHUT_RDWR)  # Запретить дальнейшую отправку и получение данных
            except OSError:  # Уже закрыт или в ошибочном состоянии
                pass
            try:
                sock.close()
            except OSError:  # Уже закрыт или в ошибочном состоянии
                pass


def start_port_forwarding(local_host, local_port, remote_host):
    """Запускает сервер проброса портов."""
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # Переиспользовать адрес, если сервер перезапускается

    try:
        server_socket.bind((local_host, local_port))
        server_socket.listen(5)  # Очередь ожидания до 5 соединений
        remote_port = local_port  # Удаленный порт теперь совпадает с локальным
        print(f"Сервер проброса портов запущен на {local_host}:{local_port}, перенаправление на {remote_host}:{remote_port} (тот же порт)")

        while True:
            client_socket, client_address = server_socket.accept()
            print(f"Получено соединение от: {client_address[0]}:{client_address[1]}")

            client_thread = threading.Thread(target=handle_client, args=(client_socket, remote_host, remote_port))
            client_thread.daemon = True  # Поток завершится при завершении основной программы
            client_thread.start()

    except Exception as e:
        print(f"Ошибка сервера: {e}")
    finally:
        shutdown_sockets(server_socket)
        print("Сервер проброса портов остановлен.")


if __name__ == "__main__":
    start_port_forwarding(LOCAL_HOST, LOCAL_PORT, REMOTE_HOST)

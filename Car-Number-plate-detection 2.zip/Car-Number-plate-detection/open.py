import serial
import serial.tools.list_ports
import time

def find_arduino_leonardo():
    """
    Ищет Arduino Leonardo среди доступных серийных портов.

    Returns:
        serial.Serial или None: Объект серийного порта, если Arduino Leonardo найдена, иначе None.
    """
    ports = list(serial.tools.list_ports.comports())
    for port in ports:
        if "Arduino Leonardo" in port.description:  # Проверяем описание порта
            try:
                arduino_port = serial.Serial(port.device, baudrate=9600, timeout=2) # Попробуем подключиться
                print(f"Arduino Leonardo найдена на порту: {port.device}")
                return arduino_port
            except serial.SerialException:
                print(f"Не удалось открыть порт {port.device}. Возможно, порт занят или Arduino не отвечает.")
    return None

def main():
    arduino_port = find_arduino_leonardo()

    if arduino_port:
        try:
            print("Отправляем команду '1'...")
            arduino_port.write(b'1')  # Отправляем '1' как байты
            time.sleep(1) # Даем время на обработку команды на Arduino, если нужно
            print("Команда '1' отправлена.")

            time.sleep(30)  # Ждем 30 секунд

            print("Отправляем команду '2'...")
            arduino_port.write(b'2')  # Отправляем '2' как байты
            time.sleep(1) # Даем время на обработку команды на Arduino, если нужно
            print("Команда '2' отправлена.")

        except serial.SerialException as e:
            print(f"Ошибка серийной связи: {e}")
        finally:
            arduino_port.close()
            print("Серийный порт закрыт.")
    else:
        print("Arduino Leonardo не найдена.")

if __name__ == "__main__":
    main()
